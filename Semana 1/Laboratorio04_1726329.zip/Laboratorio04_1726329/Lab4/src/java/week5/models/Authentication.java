 package week5.models;


public class Authentication {
    
    public static boolean authenticate(String username, String password) {

        
        User user = new User();
        
        if(username.equals(user.getUsername()) && password.equals(user.getPassword())) {
            return true;
        }
        else {
            return false;
        }
    }
}
    
