package week5.models;

/**
 *
 * @author 
 */
public class User {
    
    private String username;
    private String email;
    private String password;
    private String nombre;
    private String apellidos;
    private String ocupacion;

    public User() {
        this.username = "Popo123";
        this.email = "hola@gmail.com";
        this.password = "1234";
        this.nombre = "Aracely";
        this.apellidos = "Aguiñaga";
        this.ocupacion = "Estudiante";
    }
    
    public void setUsername(String user) {
        this.username = user;
    }
   
    public String getUsername() {
        return this.username;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getEmail() {
        return this.email;
    }
    
    public void setPassword(String pass){
        this.password = pass;
    }
    
    public String getPassword(){
        return this.password;
    }
    
    public void setName(String name) {
        this.nombre = name;
    }
    
    public String getName() {
        return this.nombre;
    }
     
    public void setApellido(String d) {
        this.apellidos = d;
    }
    
    public String getApellido() {
        return this.apellidos;
    }
    
    public void setOcupacion(String e) {
        this.ocupacion = e;
    }
    
    public String getOcupacion() {
        return this.ocupacion   ;
    }  
}
