package Laboratorio6.model;

public class Authentication {
     public static boolean authenticate(String username, String password){
        
        String userDataBase= "Eduardo";
        String passwordDataBase="1234";
       
         if(username.equals(userDataBase) && password.equals(passwordDataBase)) {
            return true;
        }
        else {
            return false;
        }
     }
    
}
