/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author seg-6
 */
public class User {
    
    private String usuario;
    private String contraseña;
    private String email;
    private String nombre;
    private String apellido;
    private String ocupacion;
    
    public User 
}
