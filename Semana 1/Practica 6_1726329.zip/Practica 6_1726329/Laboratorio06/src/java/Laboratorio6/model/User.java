package Laboratorio6.model;

public class User {
    private String username;
    private String password;
    private String nombre;
    private String apellido;
    
   
   public User(String username , String password){
       this.username= username;
       nombre = "Eduardo";
       apellido = "Alvarado";
       this.password = password;
       
   }
   
   public String getUsername(){
       return username;
}
   public String getName(){
       return nombre;
   }
   
   public String getLastName(){
       return apellido;
   }
   
   public String getFullName(){
       return getName() + " " + getLastName();
   }
}
